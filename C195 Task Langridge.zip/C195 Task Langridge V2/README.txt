C195 Task - Scheduling Application Accessing a Database

Caroline Langridge
ID: 001470808
clangr1@wgu.edu
Version 2
04/08/2023

IntelliJ IDEA Community Edition 2021.3.2
JDK openjdk-17.0.2
JavaFX openjfx-17.0.2_windows-x64_bin-sdk\javafx-sdk-17.0.2\lib\javafx.fxml.jar

After logging in, use the buttons to navigate the different screens and access appointments, customers, and reports.

Reports :
    Report 1: I was confused by the wording in the task instructions, so I made 2 tables.
    One counts the number of appointments by type, and the other counts appointments by month.
    An instructor said that should be fine as long as I explain what I did.
    Report 3: Displays all customers by country.

Lambdas :
    Lambda #1: Located in timeZone -> TimeZone -> getAppointmentStartTimes()
    Lambda #2: Located in DAO -> DBAppointments -> getAppointmentsMonth()

SQL Driver mysql-connector-java-8.0.30.jar


