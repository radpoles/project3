module com.example.c195tasklangridge {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.c195tasklangridge to javafx.fxml;
    exports com.example.c195tasklangridge;
    exports com.example.c195tasklangridge.controller;
    opens com.example.c195tasklangridge.controller to javafx.fxml;
    exports com.example.c195tasklangridge.model;
    opens com.example.c195tasklangridge.model to javafx.fxml;
    exports com.example.c195tasklangridge.DAO;
    opens com.example.c195tasklangridge.DAO to javafx.fxml;
}